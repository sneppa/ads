package uebung04;

import static gdi.MakeItSimple.println;

public class ShellSort {
	
	static final int LENGTH = 4096;
	static final int RUNS = 100;
	static int comparisons = 0;
	static int writes = 0;
	static int executions = 0;
	static boolean protocol = false;
	    
	public static void main(String[] args) {

		int[] array = {9,6,3,8,5,12,61,23,62,8,0,1,2,6,4,6,1};
		printProtocol(array);
		
		calculateEffort();
	}
	
	
	/**
	 * Prints the sorting protocol for the given array.
	 * @param array Array which has to be protocolled.
	 */
	public static void printProtocol(int[] array) {
		
		protocol = true;
		shellSort(array);
		protocol = false;
	}
	
	
	/**
	 * Calculates the amount of comparisons and swaps that is needed to shellsort an array of LENGTH on average.
	 */
	public static void calculateEffort() {
		
		int[] values = new int[LENGTH];
        
		for (int i = 1; i <= RUNS; i++) {
            for (int k = 0; k < LENGTH; k++) {
            	values[k] = (int) Math.floor(Math.random()*LENGTH);
            }
            shellSort(values);
        }
		
        println("Durchschnittliche Anzahl der Vergleiche: " + comparisons/RUNS + " - Anzahl der Arrayzugriffe: " + writes/RUNS + " - Anzahl der Ausführungen: " + executions/RUNS);
	}
	
	/**
	 * Uses the shellSort algorithm to sort given array. ShellSort does basically InsertionSort but with first with runs of larger distances while
	 * the distance decreases every time.
	 * @param array The array which has to be sorted.
	 */
	static void shellSort (int[] array) { 
	 
	    int[] rows = {9,7,4,1};
	 
	    //First sort all values with rows[k] distance then k-1, etc...
	    for (int k = 0; k < rows.length; k++) { 
	    	int i;
	        int distance = rows[k];
	        //i = offset. Example: at distance = 9 first run will be array[0], array[9], array[18]... second: array[1], array[10], array[19]...
	        for (i = distance; i < array.length; i++) { 
	            int value = array[i];
	            writes++;
	            int j = i;
	            //Basically InsertionSort only looking at elements with given distance
	            while (j >= distance && array[j - distance] > value) { 
	                array[j] = array[j - distance];
	                j = j - distance;
	                comparisons++;
	                writes++;
	            }
	            array[j] = value;
	            writes++;
	            
	            //Protocol
	            if(protocol && distance > 1) {
					String output = "";
					for(int l = 0; l < array.length; l++) {
						if(l%distance == i%distance)
							output = output + "[" + array[l] + "] ";
						else
							output = output + array[l] + " ";
					}
					println("Distanz " + distance + ": " + output);
				}
	            
    	        //Runs of shellSort
    	        executions++;
	        }
	        
	        //Protocol
	        if(protocol && distance == 1) {
				String output = "";
				for(int l = 0; l < array.length; l++) {
					output = output + "[" + array[l] + "] ";
				}
				println("Distanz " + distance + ": " + output);
			}
	    }
	}

}
